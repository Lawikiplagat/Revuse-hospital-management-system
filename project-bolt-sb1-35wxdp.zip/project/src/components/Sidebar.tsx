import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Users,
  Calendar,
  FileText,
  DollarSign,
  UserCog,
  Package,
  LayoutDashboard,
  Activity,
  Settings,
} from 'lucide-react';

const Sidebar = () => {
  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: Users, label: 'Patients', path: '/patients' },
    { icon: Calendar, label: 'Appointments', path: '/appointments' },
    { icon: FileText, label: 'Medical Records', path: '/records' },
    { icon: DollarSign, label: 'Billing', path: '/billing' },
    { icon: UserCog, label: 'Staff', path: '/staff' },
    { icon: Package, label: 'Inventory', path: '/inventory' },
    { icon: Activity, label: 'Analytics', path: '/analytics' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  return (
    <div className="bg-white h-screen w-64 fixed left-0 top-0 shadow-lg">
      <div className="flex items-center justify-center h-16 border-b">
        <Activity className="h-8 w-8 text-blue-600" />
        <span className="ml-2 text-xl font-bold text-gray-800">MediCare</span>
      </div>
      <nav className="mt-8">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center px-6 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                isActive ? 'bg-blue-50 text-blue-600' : ''
              }`
            }
          >
            <item.icon className="h-5 w-5" />
            <span className="ml-3">{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;