export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  contact: string;
  email: string;
  address: string;
  bloodGroup: string;
  medicalHistory: string[];
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  date: Date;
  time: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  type: string;
  notes?: string;
}

export interface Staff {
  id: string;
  name: string;
  role: 'doctor' | 'nurse' | 'admin' | 'receptionist';
  department: string;
  specialization?: string;
  contact: string;
  email: string;
  schedule: {
    day: string;
    hours: string;
  }[];
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorId: string;
  date: Date;
  diagnosis: string;
  prescription: string[];
  notes: string;
  attachments?: string[];
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  reorderLevel: number;
  supplier: string;
  lastRestocked: Date;
}

export interface Bill {
  id: string;
  patientId: string;
  date: Date;
  items: {
    description: string;
    amount: number;
  }[];
  total: number;
  status: 'pending' | 'paid' | 'overdue';
  paymentMethod?: string;
}