import React, { useState } from 'react';
import { FileText, Search, Filter, Plus, Download } from 'lucide-react';
import type { MedicalRecord } from '../types';
import { format } from 'date-fns';

const MedicalRecords = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const records: MedicalRecord[] = [
    {
      id: '1',
      patientId: '1',
      doctorId: '1',
      date: new Date(),
      diagnosis: 'Common Cold',
      prescription: ['Paracetamol', 'Vitamin C'],
      notes: 'Rest and hydration recommended',
      attachments: ['xray.pdf', 'blood_test.pdf']
    },
    {
      id: '2',
      patientId: '1',
      doctorId: '2',
      date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      diagnosis: 'Hypertension',
      prescription: ['Amlodipine'],
      notes: 'Blood pressure monitoring required',
      attachments: ['bp_chart.pdf']
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Medical Records</h1>
        <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Plus className="h-5 w-5 mr-2" />
          New Record
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search records..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
              <Filter className="h-5 w-5 mr-2" />
              Filters
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            {records.map((record) => (
              <div
                key={record.id}
                className="p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center">
                      <FileText className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">
                        {record.diagnosis}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {format(record.date, 'MMM dd, yyyy')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {record.attachments && record.attachments.length > 0 && (
                      <button className="flex items-center px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded-lg">
                        <Download className="h-4 w-4 mr-1" />
                        Attachments ({record.attachments.length})
                      </button>
                    )}
                    <button className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg">
                      View Details
                    </button>
                  </div>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-900">
                    Prescription
                  </h4>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {record.prescription.map((med, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 text-xs rounded-md bg-gray-100 text-gray-600"
                      >
                        {med}
                      </span>
                    ))}
                  </div>
                  {record.notes && (
                    <p className="mt-2 text-sm text-gray-600">{record.notes}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MedicalRecords;