import React, { useState } from 'react';
import { Calendar, Clock, Search, Filter, Plus } from 'lucide-react';
import type { Appointment } from '../types';
import { format } from 'date-fns';

const Appointments = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const appointments: Appointment[] = [
    {
      id: '1',
      patientId: '1',
      doctorId: '1',
      date: new Date(),
      time: '09:00',
      status: 'scheduled',
      type: 'General Checkup',
      notes: 'Regular health checkup'
    },
    {
      id: '2',
      patientId: '2',
      doctorId: '3',
      date: new Date(),
      time: '10:30',
      status: 'completed',
      type: 'Dental Checkup',
      notes: 'Regular dental cleaning'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Appointments</h1>
        <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Plus className="h-5 w-5 mr-2" />
          New Appointment
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search appointments..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex space-x-3">
              <button className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
                <Calendar className="h-5 w-5 mr-2" />
                Date
              </button>
              <button className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </button>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            {appointments.map((appointment) => (
              <div
                key={appointment.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center space-x-4">
                  <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {appointment.type}
                    </h3>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>
                        {format(appointment.date, 'MMM dd, yyyy')} at{' '}
                        {appointment.time}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-medium
                    ${
                      appointment.status === 'scheduled'
                        ? 'bg-green-100 text-green-800'
                        : appointment.status === 'completed'
                        ? 'bg-gray-100 text-gray-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {appointment.status.charAt(0).toUpperCase() +
                      appointment.status.slice(1)}
                  </span>
                  <button className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Appointments;