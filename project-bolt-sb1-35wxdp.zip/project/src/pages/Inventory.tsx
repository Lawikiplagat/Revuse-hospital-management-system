import React, { useState } from 'react';
import { Package, Search, Filter, Plus, AlertTriangle } from 'lucide-react';
import type { InventoryItem } from '../types';
import { format } from 'date-fns';

const Inventory = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const inventory: InventoryItem[] = [
    {
      id: '1',
      name: 'Surgical Masks',
      category: 'PPE',
      quantity: 1500,
      unit: 'pieces',
      reorderLevel: 500,
      supplier: 'Medical Supplies Co.',
      lastRestocked: new Date()
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Inventory Management</h1>
        <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Plus className="h-5 w-5 mr-2" />
          Add Item
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search inventory..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
              <Filter className="h-5 w-5 mr-2" />
              Filters
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            {inventory.map((item) => (
              <div
                key={item.id}
                className="p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="h-12 w-12 rounded-full bg-orange-100 flex items-center justify-center">
                      <Package className="h-6 w-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{item.name}</h3>
                      <p className="text-sm text-gray-500">
                        {item.category} • Last restocked:{' '}
                        {format(item.lastRestocked, 'MMM dd, yyyy')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-8">
                    <div>
                      <p className="text-lg font-semibold text-gray-900">
                        {item.quantity} {item.unit}
                      </p>
                      {item.quantity <= item.reorderLevel && (
                        <div className="flex items-center text-sm text-amber-600">
                          <AlertTriangle className="h-4 w-4 mr-1" />
                          Low Stock
                        </div>
                      )}
                    </div>
                    <button className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg">
                      Update Stock
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inventory;