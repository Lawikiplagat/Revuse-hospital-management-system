import React from 'react';
import { BarChart, Activity, TrendingUp, Users } from 'lucide-react';

const Analytics = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h1>
        <div className="flex items-center space-x-3">
          <select className="border rounded-lg px-4 py-2 bg-white">
            <option>Last 7 days</option>
            <option>Last 30 days</option>
            <option>Last 90 days</option>
          </select>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            Export Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              Patient Statistics
            </h2>
            <Users className="h-5 w-5 text-gray-400" />
          </div>
          <div className="h-[300px] flex items-center justify-center">
            <Activity className="w-full h-full text-blue-600 opacity-50" />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              Revenue Analysis
            </h2>
            <TrendingUp className="h-5 w-5 text-gray-400" />
          </div>
          <div className="h-[300px] flex items-center justify-center">
            <BarChart className="w-full h-full text-green-600 opacity-50" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">
            Department Performance
          </h2>
          <button className="text-sm text-blue-600 hover:text-blue-700">
            View Details
          </button>
        </div>
        <div className="space-y-4">
          {['Cardiology', 'Neurology', 'Pediatrics', 'Orthopedics'].map(
            (dept) => (
              <div
                key={dept}
                className="flex items-center justify-between p-4 border rounded-lg"
              >
                <span className="font-medium text-gray-900">{dept}</span>
                <div className="flex items-center space-x-4">
                  <div className="w-48 h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 rounded-full"
                      style={{
                        width: `${Math.floor(Math.random() * 100)}%`,
                      }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-500">
                    {Math.floor(Math.random() * 100)}%
                  </span>
                </div>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default Analytics;